# Polizei - Deutschland RP (GitHub Pages Template)

Dieses Repository enthaelt ein statisches Template. Ersetze die Platzhalter in den HTML-Dateien mit deinen echten Inhalten.

Deploy: Repo pushen und Pages auf main/root setzen.
