
document.addEventListener('click', e => {
  if(e.target.matches('.copy-link')){
    const url = window.location.href.split('?')[0];
    navigator.clipboard?.writeText(url).then(()=> alert('Seitenlink kopiert: ' + url));
  }
});
